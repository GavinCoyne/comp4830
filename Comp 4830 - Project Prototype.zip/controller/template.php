<?php

class template
{
	public $content;
	
	public function __construct($content = null) {
       include "./view/template.php";
       
   }
	
}