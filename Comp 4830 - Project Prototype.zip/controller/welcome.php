<?php 
include "./view/index.php";
