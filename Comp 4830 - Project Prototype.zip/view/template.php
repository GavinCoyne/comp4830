<html>
	<head>
		<title>
			Java tutorial and compiler
		</title>
		
	</head>
	<body>
		<div class="overall">
			<nav>
				<ul class="navigation">
					<li>
						<a href="#">Compiler Page</a>
					</li>
					<li>
						<a href="#">Basic Tutorials</a>
					</li>
					<li>
						<a href="#">Advanced Tutorials</a>
					</li>
					<li>
						<a href="#">Video Links</a>
					</li>
					<li>
						<a href="#">Descriptive Animations</a>
					</li>
					<li>
						<a href="#">Index Search</a>
					</li>
				</ul>
			</nav>
			<div class="mainbody">
				
				<?php echo (isset($content) ? $content : "No content set."); ?>
			</div>
			
			
		</div>
	</body>
</html>