<div class="tutorial" id="tutorial" >			
	<br />
	<pre><code class="Java" id="editorWindow" >
public class test()
{
	public function testCode()
	{
		System.out.println("We cans highlight code!");
	}
}
	</code></pre>
	<input type="text" id="editorInput" name="editor" class="editor" onKeypress="test();" />
</div>


<button type="submit" class="btn btn-primary">Compile</button>


<div class="console">
	<pre>Console text... </pre>
</div>