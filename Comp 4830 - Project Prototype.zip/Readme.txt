Hello Dr. Park,
Just a friendly reminder that this application needs a server-side base, thus links are included. The main navigation links are not yet live, as is the canvas work we have planned, but we felt it best to get out site framework in place first and then complete the simpler animations and various multimedia aligned with the tutorials.
Jonathan